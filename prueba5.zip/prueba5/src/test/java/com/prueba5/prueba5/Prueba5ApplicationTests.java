package com.prueba5.prueba5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prueba5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
