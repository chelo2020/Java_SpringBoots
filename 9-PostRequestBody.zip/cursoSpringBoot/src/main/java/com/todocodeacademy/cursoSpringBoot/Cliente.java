package com.todocodeacademy.cursoSpringBoot;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Cliente {
    
    private Long id;
    private String nombre;
    private String apellido;

}

