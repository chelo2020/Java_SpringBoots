package com.todocodeacademy.promedio_notas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PromedioNotasApplication {

	public static void main(String[] args) {
		SpringApplication.run(PromedioNotasApplication.class, args);
	}

}
