package com.todocodeacademy.area_triangulo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AreaTrianguloApplicationTests {

	@Test
	void contextLoads() {
	}

}
