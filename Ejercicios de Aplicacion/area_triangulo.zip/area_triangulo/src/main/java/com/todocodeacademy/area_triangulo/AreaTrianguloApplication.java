package com.todocodeacademy.area_triangulo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AreaTrianguloApplication {

	public static void main(String[] args) {
		SpringApplication.run(AreaTrianguloApplication.class, args);
	}

}
