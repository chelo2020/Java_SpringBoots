package com.todocodeacademy.estaturas_basquet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstaturasBasquetApplicationTests {

	@Test
	void contextLoads() {
	}

}
