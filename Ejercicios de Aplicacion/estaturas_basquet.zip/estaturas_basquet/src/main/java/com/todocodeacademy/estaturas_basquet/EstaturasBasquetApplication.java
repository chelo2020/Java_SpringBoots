package com.todocodeacademy.estaturas_basquet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstaturasBasquetApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstaturasBasquetApplication.class, args);
	}

}
