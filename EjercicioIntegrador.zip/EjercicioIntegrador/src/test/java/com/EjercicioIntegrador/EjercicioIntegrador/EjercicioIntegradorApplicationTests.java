package com.EjercicioIntegrador.EjercicioIntegrador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioIntegradorApplicationTests {

	@Test
	void contextLoads() {
	}

}
