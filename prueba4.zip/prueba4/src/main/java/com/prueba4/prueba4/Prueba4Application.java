package com.prueba4.prueba4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prueba4Application {

	public static void main(String[] args) {
		SpringApplication.run(Prueba4Application.class, args);
	}

}
