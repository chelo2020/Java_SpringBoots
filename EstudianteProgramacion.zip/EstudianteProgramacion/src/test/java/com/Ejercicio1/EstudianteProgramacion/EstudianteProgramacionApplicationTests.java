package com.Ejercicio1.EstudianteProgramacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstudianteProgramacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
