package com.pruebajpa2.pruebajpa2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pruebajpa2Application {

	public static void main(String[] args) {
		SpringApplication.run(Pruebajpa2Application.class, args);
	}

}
