package com.pruebajpa2.pruebajpa2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pruebajpa2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
