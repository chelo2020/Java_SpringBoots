package com.ClinicaVeterinaria.Ejercicion2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicion2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
