package com.somi.basedeDatos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasedeDatosApplicationTests {

	@Test
	void contextLoads() {
	}

}
