
package com.todocodeacademy.pruebaJPA.service;


public interface IPersonaService {
    
}
