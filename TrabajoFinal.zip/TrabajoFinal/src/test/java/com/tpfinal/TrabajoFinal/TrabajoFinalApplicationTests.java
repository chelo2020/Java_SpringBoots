package com.tpfinal.TrabajoFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
