package com.ClinicaVeterinaria.Ejercicion2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicion2Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicion2Application.class, args);
	}

}
