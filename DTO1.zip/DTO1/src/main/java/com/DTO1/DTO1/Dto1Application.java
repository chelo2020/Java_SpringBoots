package com.DTO1.DTO1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dto1Application {

	public static void main(String[] args) {
		SpringApplication.run(Dto1Application.class, args);
	}

}
