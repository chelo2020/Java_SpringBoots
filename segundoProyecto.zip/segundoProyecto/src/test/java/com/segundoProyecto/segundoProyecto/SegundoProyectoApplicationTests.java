package com.segundoProyecto.segundoProyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegundoProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
