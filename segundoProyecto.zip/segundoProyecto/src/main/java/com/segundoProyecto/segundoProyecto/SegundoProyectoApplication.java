package com.segundoProyecto.segundoProyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegundoProyectoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegundoProyectoApplication.class, args);
	}

}
