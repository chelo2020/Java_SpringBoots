package com.miprimerproyecto.miprimerproyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiprimerproyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
